<?php

if(!class_exists('Options_Class')){
	/* Class to save and update options */
	class Options_Class(){
		public function __construct() {
		}
	}
}